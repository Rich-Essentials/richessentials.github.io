---
layout: page
title: About
permalink: /about/
---

**Rich Essentials** is run by a veteran IT professional focused on helping others break into the tech industry through real-world guidance and consulting tips.
